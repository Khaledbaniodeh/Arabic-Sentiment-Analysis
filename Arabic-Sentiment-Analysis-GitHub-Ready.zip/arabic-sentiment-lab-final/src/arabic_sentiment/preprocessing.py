"""Arabic-aware text cleaning and normalization.

The default pipeline deliberately avoids aggressive stemming. Dialectal Arabic and short
social-media posts often lose useful sentiment cues when over-stemmed. Character n-grams
provide robustness to morphology and spelling variation without destroying the surface form.
"""

from __future__ import annotations

import html
import re
import unicodedata

ARABIC_DIACRITICS_RE = re.compile(r"[\u0617-\u061A\u064B-\u0652\u0670\u06D6-\u06ED]")
HTML_TAG_RE = re.compile(r"<[^>]+>")
URL_RE = re.compile(r"(?:https?://|www\.)\S+", flags=re.IGNORECASE)
MENTION_RE = re.compile(r"@\w+")
NUMBER_RE = re.compile(r"\d+(?:[.,:/-]\d+)*")
REPEATED_CHAR_RE = re.compile(r"(.)\1{2,}", flags=re.UNICODE)
WHITESPACE_RE = re.compile(r"\s+")

POSITIVE_EMOJI_RE = re.compile(
    r"[:;=8xX][\-^']?[)D]+|[❤♥😍😘😊😁😃😄☺🙂🤩🥰👍👏🎉✨💙💚💛]",
    flags=re.UNICODE,
)
NEGATIVE_EMOJI_RE = re.compile(
    r"[:;=8xX][\-^']?[(\/\\]+|[😢😭😔😞😡😠💔👎😒😕☹]",
    flags=re.UNICODE,
)

NEGATORS = {
    "لا",
    "لم",
    "لن",
    "ما",
    "مش",
    "مو",
    "موش",
    "ليس",
    "بدون",
    "غير",
    "ولا",
    "مفيش",
}

ARABIC_TRANSLATION = str.maketrans(
    {
        "أ": "ا",
        "إ": "ا",
        "آ": "ا",
        "ٱ": "ا",
        "ى": "ي",
        "ؤ": "و",
        "ئ": "ي",
    }
)


def normalize_arabic_text(text: str, negation_scope: int = 3) -> str:
    """Normalize an Arabic social-media post into a stable token sequence.

    Operations include Unicode normalization, HTML/URL/user/number standardization,
    diacritic and tatweel removal, Arabic letter unification, emoji standardization,
    hashtag preservation, elongation reduction, and lightweight negation marking.
    """

    value = unicodedata.normalize("NFKC", html.unescape(str(text))).lower()
    value = HTML_TAG_RE.sub(" ", value)
    value = URL_RE.sub(" رابط ", value)
    value = MENTION_RE.sub(" مستخدم ", value)
    value = POSITIVE_EMOJI_RE.sub(" ايموجي_ايجابي ", value)
    value = NEGATIVE_EMOJI_RE.sub(" ايموجي_سلبي ", value)
    value = NUMBER_RE.sub(" رقم ", value)
    value = value.replace("ـ", "")
    value = ARABIC_DIACRITICS_RE.sub("", value)
    value = value.translate(ARABIC_TRANSLATION)

    # Keep hashtag content while exposing it to word tokenization.
    value = value.replace("#", " هاشتاق_").replace("_", " ")
    value = REPEATED_CHAR_RE.sub(r"\1\1", value)
    value = re.sub(r"[^\u0600-\u06FFa-zA-Z ]+", " ", value)
    value = WHITESPACE_RE.sub(" ", value).strip()

    tokens = value.split()
    output: list[str] = []
    remaining_scope = 0
    for token in tokens:
        output.append(token)
        if token in NEGATORS:
            remaining_scope = negation_scope
            continue
        if remaining_scope > 0 and token not in {"رابط", "مستخدم", "رقم"}:
            output.append(f"نفي_{token}")
            remaining_scope -= 1
    return " ".join(output)


def simple_tokenizer(text: str) -> list[str]:
    """Tokenize already-normalized text without downloading external resources."""

    return text.split()
