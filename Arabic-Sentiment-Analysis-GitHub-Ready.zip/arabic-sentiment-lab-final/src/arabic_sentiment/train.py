"""End-to-end training, validation tuning, test evaluation, and artifact generation."""

from __future__ import annotations

import hashlib
import logging
import platform
import time
from copy import deepcopy
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.decomposition import TruncatedSVD
from sklearn.model_selection import ParameterGrid
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.utils.class_weight import compute_sample_weight

from .config import ProjectConfig, load_config
from .data import load_dataset, split_manifest, stratified_split
from .evaluation import (
    compute_metrics,
    plot_class_distribution,
    plot_confusion_matrix,
    plot_model_comparison,
    plot_text_length_distribution,
    save_json,
)
from .features import build_feature_extractor
from .modeling import (
    ModelBundle,
    make_linear_svm,
    make_mlp,
    make_naive_bayes,
    make_random_forest,
    oversample_to_majority,
)

LOGGER = logging.getLogger(__name__)

DISPLAY_NAMES = {
    "naive_bayes": "Complement Naive Bayes",
    "random_forest": "Random Forest",
    "neural_network": "Artificial Neural Network",
    "linear_svm": "Linear SVM (production baseline)",
}


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def _score_candidate(
    family: str,
    params: dict[str, Any],
    y_validation_labels: np.ndarray,
    predictions_encoded: np.ndarray,
    encoder: LabelEncoder,
    elapsed_seconds: float,
) -> dict[str, Any]:
    predicted_labels = encoder.inverse_transform(np.asarray(predictions_encoded, dtype=int))
    metrics = compute_metrics(y_validation_labels, predicted_labels)
    return {
        "family": family,
        "display_name": DISPLAY_NAMES[family],
        "params": deepcopy(params),
        "validation_metrics": {
            key: value
            for key, value in metrics.items()
            if key not in {"classification_report", "confusion_matrix"}
        },
        "elapsed_seconds": round(elapsed_seconds, 3),
    }


def _best_candidate(rows: list[dict[str, Any]], primary_metric: str) -> dict[str, Any]:
    if not rows:
        raise ValueError("No candidate results were produced.")
    metric_key = primary_metric.replace("validation_", "")
    return max(
        rows,
        key=lambda row: (
            row["validation_metrics"].get(metric_key, float("-inf")),
            row["validation_metrics"].get("weighted_f1", float("-inf")),
            row["validation_metrics"].get("accuracy", float("-inf")),
        ),
    )


def _prepare_directories(config: ProjectConfig) -> dict[str, Path]:
    paths = {
        "processed": config.path("paths.processed_data"),
        "models": config.path("paths.models"),
        "metrics": config.path("paths.metrics"),
        "plots": config.path("paths.plots"),
        "docs": config.path("paths.docs"),
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def _train_validation_candidates(
    config: ProjectConfig,
    X_train: Any,
    X_validation: Any,
    y_train: np.ndarray,
    validation_labels: np.ndarray,
    label_encoder: LabelEncoder,
    X_train_dense: np.ndarray,
    X_validation_dense: np.ndarray,
    scaler: StandardScaler,
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    seed = int(config.get("random_seed", 42))
    selection_metric = str(config.get("training.selection_metric", "macro_f1"))
    all_results: list[dict[str, Any]] = []
    selected: dict[str, dict[str, Any]] = {}

    # Naive Bayes: optimized on sparse content + handcrafted features.
    family_results = []
    for params in ParameterGrid(config.get("models.naive_bayes.grid")):
        started = time.perf_counter()
        model = make_naive_bayes(params)
        model.fit(X_train, y_train)
        predictions = model.predict(X_validation)
        family_results.append(
            _score_candidate(
                "naive_bayes",
                params,
                validation_labels,
                predictions,
                label_encoder,
                time.perf_counter() - started,
            )
        )
    all_results.extend(family_results)
    selected["naive_bayes"] = _best_candidate(family_results, selection_metric)

    # Linear SVM is an additional strong production-oriented text baseline.
    family_results = []
    for params in ParameterGrid(config.get("models.linear_svm.grid")):
        started = time.perf_counter()
        model = make_linear_svm(params, seed)
        model.fit(X_train, y_train)
        predictions = model.predict(X_validation)
        family_results.append(
            _score_candidate(
                "linear_svm",
                params,
                validation_labels,
                predictions,
                label_encoder,
                time.perf_counter() - started,
            )
        )
    all_results.extend(family_results)
    selected["linear_svm"] = _best_candidate(family_results, selection_metric)

    # Random Forest: SVD makes the high-dimensional sparse text representation tractable.
    balanced_X, balanced_y = oversample_to_majority(X_train_dense, y_train, seed)
    family_results = []
    for params in ParameterGrid(config.get("models.random_forest.grid")):
        started = time.perf_counter()
        model = make_random_forest(params, seed)
        model.fit(balanced_X, balanced_y)
        predictions = model.predict(X_validation_dense)
        family_results.append(
            _score_candidate(
                "random_forest",
                params,
                validation_labels,
                predictions,
                label_encoder,
                time.perf_counter() - started,
            )
        )
    all_results.extend(family_results)
    selected["random_forest"] = _best_candidate(family_results, selection_metric)

    # ANN: MLP over scaled latent semantic components.
    train_scaled = scaler.transform(X_train_dense)
    validation_scaled = scaler.transform(X_validation_dense)
    balanced_weights = compute_sample_weight(class_weight="balanced", y=y_train)
    weight_power = float(config.get("models.neural_network.sample_weight_power", 0.5))
    sample_weights = np.power(balanced_weights, weight_power)
    sample_weights = sample_weights / np.mean(sample_weights)

    family_results = []
    for params in config.get("models.neural_network.candidates"):
        started = time.perf_counter()
        model = make_mlp(params, seed)
        model.fit(train_scaled, y_train, sample_weight=sample_weights)
        predictions = model.predict(validation_scaled)
        candidate = _score_candidate(
            "neural_network",
            params,
            validation_labels,
            predictions,
            label_encoder,
            time.perf_counter() - started,
        )
        candidate["training_iterations"] = int(model.n_iter_)
        family_results.append(candidate)
    all_results.extend(family_results)
    selected["neural_network"] = _best_candidate(family_results, selection_metric)

    return all_results, selected


def _fit_final_models(
    config: ProjectConfig,
    selected: dict[str, dict[str, Any]],
    feature_extractor: Any,
    reducer: TruncatedSVD,
    scaler: StandardScaler,
    X_full: Any,
    X_test: Any,
    X_full_dense: np.ndarray,
    X_test_dense: np.ndarray,
    full_labels: np.ndarray,
    test_labels: np.ndarray,
    encoder: LabelEncoder,
    plots_directory: Path,
    metrics_directory: Path,
) -> tuple[list[dict[str, Any]], dict[str, ModelBundle]]:
    seed = int(config.get("random_seed", 42))
    y_full = encoder.transform(full_labels)
    results: list[dict[str, Any]] = []
    bundles: dict[str, ModelBundle] = {}

    def evaluate_and_store(
        family: str,
        estimator: Any,
        predictions_encoded: np.ndarray,
        family_reducer: Any = None,
        family_scaler: Any = None,
        fit_seconds: float = 0.0,
        extra: dict[str, Any] | None = None,
    ) -> None:
        predictions = encoder.inverse_transform(np.asarray(predictions_encoded, dtype=int))
        metrics = compute_metrics(test_labels, predictions)
        result = {
            "family": family,
            "display_name": DISPLAY_NAMES[family],
            "selected_params": selected[family]["params"],
            "validation_metrics": selected[family]["validation_metrics"],
            "test_metrics": metrics,
            "fit_seconds": round(fit_seconds, 3),
        }
        if extra:
            result.update(extra)
        results.append(result)
        plot_confusion_matrix(
            metrics["confusion_matrix"],
            DISPLAY_NAMES[family],
            plots_directory / f"confusion_matrix_{family}.png",
        )
        report_frame = pd.DataFrame(metrics["classification_report"]).transpose()
        report_frame.to_csv(metrics_directory / f"classification_report_{family}.csv", index=True)
        bundles[family] = ModelBundle(
            feature_extractor=feature_extractor,
            estimator=estimator,
            label_encoder=encoder,
            reducer=family_reducer,
            scaler=family_scaler,
            metadata={
                "family": family,
                "display_name": DISPLAY_NAMES[family],
                "selected_params": selected[family]["params"],
                "validation_metrics": selected[family]["validation_metrics"],
                "test_metrics": {
                    k: v
                    for k, v in metrics.items()
                    if k not in {"classification_report", "confusion_matrix"}
                },
            },
        )

    started = time.perf_counter()
    naive_bayes = make_naive_bayes(selected["naive_bayes"]["params"])
    naive_bayes.fit(X_full, y_full)
    evaluate_and_store(
        "naive_bayes",
        naive_bayes,
        naive_bayes.predict(X_test),
        fit_seconds=time.perf_counter() - started,
    )

    started = time.perf_counter()
    linear_svm = make_linear_svm(selected["linear_svm"]["params"], seed)
    linear_svm.fit(X_full, y_full)
    evaluate_and_store(
        "linear_svm",
        linear_svm,
        linear_svm.predict(X_test),
        fit_seconds=time.perf_counter() - started,
    )

    started = time.perf_counter()
    balanced_X, balanced_y = oversample_to_majority(X_full_dense, y_full, seed)
    random_forest = make_random_forest(selected["random_forest"]["params"], seed)
    random_forest.fit(balanced_X, balanced_y)
    evaluate_and_store(
        "random_forest",
        random_forest,
        random_forest.predict(X_test_dense),
        family_reducer=reducer,
        fit_seconds=time.perf_counter() - started,
    )

    started = time.perf_counter()
    full_scaled = scaler.transform(X_full_dense)
    test_scaled = scaler.transform(X_test_dense)
    balanced_weights = compute_sample_weight(class_weight="balanced", y=y_full)
    power = float(config.get("models.neural_network.sample_weight_power", 0.5))
    sample_weights = np.power(balanced_weights, power)
    sample_weights = sample_weights / np.mean(sample_weights)
    neural_network = make_mlp(selected["neural_network"]["params"], seed)
    neural_network.fit(full_scaled, y_full, sample_weight=sample_weights)
    evaluate_and_store(
        "neural_network",
        neural_network,
        neural_network.predict(test_scaled),
        family_reducer=reducer,
        family_scaler=scaler,
        fit_seconds=time.perf_counter() - started,
        extra={"training_iterations": int(neural_network.n_iter_)},
    )

    return results, bundles


def train_project(config_path: str | Path) -> dict[str, Any]:
    _configure_logging()
    config = load_config(config_path)
    paths = _prepare_directories(config)
    seed = int(config.get("random_seed", 42))
    np.random.seed(seed)

    dataset_path = config.path("data.path")
    LOGGER.info("Loading dataset from %s", dataset_path)
    frame, audit = load_dataset(
        dataset_path, deduplicate=bool(config.get("data.deduplicate", True))
    )
    LOGGER.info("Loaded %d usable posts", len(frame))

    plot_class_distribution(audit.class_counts_merged, paths["plots"] / "class_distribution.png")
    plot_text_length_distribution(frame, paths["plots"] / "text_length_distribution.png")

    split_cfg = config.get("data.split")
    train, validation, test = stratified_split(
        frame,
        train_size=float(split_cfg["train"]),
        validation_size=float(split_cfg["validation"]),
        test_size=float(split_cfg["test"]),
        random_state=seed,
    )
    manifest = split_manifest(train, validation, test)
    manifest.to_csv(paths["processed"] / "dataset_splits.csv", index=False, encoding="utf-8")

    encoder = LabelEncoder().fit(frame["label"])
    y_train = encoder.transform(train["label"])

    LOGGER.info("Fitting word, character, and handcrafted features on the training split")
    features = build_feature_extractor(config.get("features"))
    started = time.perf_counter()
    X_train = features.fit_transform(train["text"])
    X_validation = features.transform(validation["text"])
    feature_fit_seconds = time.perf_counter() - started
    LOGGER.info("Training feature matrix: %s", X_train.shape)

    svd_components = int(config.get("features.svd_components", 128))
    reducer = TruncatedSVD(
        n_components=svd_components,
        n_iter=int(config.get("features.svd_iterations", 5)),
        random_state=seed,
    )
    LOGGER.info("Fitting TruncatedSVD with %d components", svd_components)
    started = time.perf_counter()
    X_train_dense = reducer.fit_transform(X_train)
    X_validation_dense = reducer.transform(X_validation)
    svd_fit_seconds = time.perf_counter() - started
    scaler = StandardScaler().fit(X_train_dense)

    validation_results, selected = _train_validation_candidates(
        config,
        X_train,
        X_validation,
        y_train,
        validation["label"].to_numpy(),
        encoder,
        X_train_dense,
        X_validation_dense,
        scaler,
    )
    pd.json_normalize(validation_results).to_csv(
        paths["metrics"] / "validation_search_results.csv", index=False
    )
    save_json(selected, paths["metrics"] / "selected_hyperparameters.json")

    LOGGER.info("Refitting features and selected models on train + validation")
    full_training = pd.concat([train, validation], ignore_index=True)
    final_features = build_feature_extractor(config.get("features"))
    started = time.perf_counter()
    X_full = final_features.fit_transform(full_training["text"])
    X_test = final_features.transform(test["text"])
    final_feature_fit_seconds = time.perf_counter() - started

    final_reducer = TruncatedSVD(
        n_components=svd_components,
        n_iter=int(config.get("features.svd_iterations", 5)),
        random_state=seed,
    )
    started = time.perf_counter()
    X_full_dense = final_reducer.fit_transform(X_full)
    X_test_dense = final_reducer.transform(X_test)
    final_svd_fit_seconds = time.perf_counter() - started
    final_scaler = StandardScaler().fit(X_full_dense)

    test_results, bundles = _fit_final_models(
        config,
        selected,
        final_features,
        final_reducer,
        final_scaler,
        X_full,
        X_test,
        X_full_dense,
        X_test_dense,
        full_training["label"].to_numpy(),
        test["label"].to_numpy(),
        encoder,
        paths["plots"],
        paths["metrics"],
    )

    comparison_rows = []
    for row in test_results:
        comparison_rows.append(
            {
                "model": row["display_name"],
                "accuracy": row["test_metrics"]["accuracy"],
                "macro_precision": row["test_metrics"]["macro_precision"],
                "macro_recall": row["test_metrics"]["macro_recall"],
                "macro_f1": row["test_metrics"]["macro_f1"],
                "weighted_f1": row["test_metrics"]["weighted_f1"],
                "validation_macro_f1": row["validation_metrics"]["macro_f1"],
            }
        )
    pd.DataFrame(comparison_rows).to_csv(
        paths["metrics"] / "test_model_comparison.csv", index=False
    )
    plot_model_comparison(test_results, paths["plots"] / "model_comparison.png")

    # Deployment selection is based only on validation performance, never on the test set.
    deployment_family = max(
        selected,
        key=lambda family: (
            selected[family]["validation_metrics"]["macro_f1"],
            selected[family]["validation_metrics"]["weighted_f1"],
        ),
    )
    deployment_bundle = bundles[deployment_family]
    model_path = paths["models"] / "best_model.joblib"
    joblib.dump(deployment_bundle, model_path, compress=3)

    config_bytes = Path(config_path).read_bytes()
    summary = {
        "project": "Arabic Sentiment Analysis",
        "created_at_utc": pd.Timestamp.utcnow().isoformat(),
        "configuration_sha256": hashlib.sha256(config_bytes).hexdigest(),
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "scikit_learn": sklearn.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
        },
        "dataset": audit.as_dict(),
        "split_sizes": {
            "train": len(train),
            "validation": len(validation),
            "test": len(test),
        },
        "split_class_counts": {
            "train": {str(k): int(v) for k, v in train["label"].value_counts().items()},
            "validation": {str(k): int(v) for k, v in validation["label"].value_counts().items()},
            "test": {str(k): int(v) for k, v in test["label"].value_counts().items()},
        },
        "features": {
            "training_matrix_shape": list(X_train.shape),
            "final_matrix_shape": list(X_full.shape),
            "svd_components": svd_components,
            "validation_svd_explained_variance": float(reducer.explained_variance_ratio_.sum()),
            "final_svd_explained_variance": float(final_reducer.explained_variance_ratio_.sum()),
        },
        "timings_seconds": {
            "initial_feature_fit": round(feature_fit_seconds, 3),
            "initial_svd_fit": round(svd_fit_seconds, 3),
            "final_feature_fit": round(final_feature_fit_seconds, 3),
            "final_svd_fit": round(final_svd_fit_seconds, 3),
        },
        "validation_candidates": validation_results,
        "selected_hyperparameters": selected,
        "test_results": test_results,
        "deployment": {
            "family": deployment_family,
            "display_name": DISPLAY_NAMES[deployment_family],
            "model_path": str(model_path.relative_to(config.root)),
            "selection_basis": "highest validation macro F1; weighted F1 used as tie-breaker",
            "file_size_bytes": int(model_path.stat().st_size),
        },
        "methodological_notes": [
            "OBJ and NEUTRAL labels were merged into the assignment's Objective/Neutral class.",
            "Hyperparameters were selected on the 20% validation split using macro F1 because the dataset is imbalanced.",
            "The 20% test split remained untouched until final evaluation.",
            "Random Forest used random oversampling and SVD-reduced features.",
            "The ANN used an MLP over standardized SVD components with square-root balanced sample weights.",
            "Linear SVM was added as a production-oriented reference beyond the three required model families.",
        ],
    }
    summary_path = paths["metrics"] / "training_summary.json"
    save_json(summary, summary_path)

    LOGGER.info("Deployment model: %s", DISPLAY_NAMES[deployment_family])
    LOGGER.info("Saved model to %s", model_path)
    LOGGER.info("Saved summary to %s", summary_path)
    return summary


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Train the Arabic sentiment analysis project.")
    parser.add_argument(
        "--config", default="configs/default.yaml", help="Path to YAML configuration"
    )
    arguments = parser.parse_args()
    train_project(arguments.config)


if __name__ == "__main__":
    main()
