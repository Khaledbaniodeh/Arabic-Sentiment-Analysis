"""Model definitions, tuning helpers, and deployable model bundle."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
from scipy.special import softmax
from sklearn.base import BaseEstimator
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import ComplementNB
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import LinearSVC


@dataclass
class ModelBundle:
    """Serializable end-to-end inference object."""

    feature_extractor: Any
    estimator: BaseEstimator
    label_encoder: LabelEncoder
    reducer: Any = None
    scaler: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def _transform(self, texts: list[str]) -> Any:
        features = self.feature_extractor.transform(texts)
        if self.reducer is not None:
            features = self.reducer.transform(features)
        if self.scaler is not None:
            features = self.scaler.transform(features)
        return features

    def predict(self, texts: list[str]) -> list[str]:
        features = self._transform(texts)
        encoded = self.estimator.predict(features)
        return self.label_encoder.inverse_transform(np.asarray(encoded, dtype=int)).tolist()

    def predict_with_scores(self, texts: list[str]) -> list[dict[str, Any]]:
        features = self._transform(texts)
        encoded = self.estimator.predict(features)
        labels = self.label_encoder.inverse_transform(np.asarray(encoded, dtype=int))

        if hasattr(self.estimator, "predict_proba"):
            probabilities = self.estimator.predict_proba(features)
        elif hasattr(self.estimator, "decision_function"):
            decision = self.estimator.decision_function(features)
            if decision.ndim == 1:
                decision = np.column_stack([-decision, decision])
            probabilities = softmax(decision, axis=1)
        else:
            probabilities = np.eye(len(self.label_encoder.classes_))[np.asarray(encoded, dtype=int)]

        results = []
        for label, row in zip(labels, probabilities, strict=True):
            scores = {
                class_label: float(row[index])
                for index, class_label in enumerate(self.label_encoder.classes_)
            }
            results.append(
                {
                    "label": str(label),
                    "confidence": float(max(scores.values())),
                    "scores": scores,
                }
            )
        return results


def make_naive_bayes(params: dict[str, Any]) -> ComplementNB:
    return ComplementNB(alpha=float(params["alpha"]), norm=bool(params.get("norm", False)))


def make_random_forest(params: dict[str, Any], random_state: int) -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=int(params["n_estimators"]),
        max_depth=params.get("max_depth"),
        min_samples_leaf=int(params.get("min_samples_leaf", 1)),
        max_features=params.get("max_features", "sqrt"),
        bootstrap=True,
        n_jobs=-1,
        random_state=random_state,
    )


def make_mlp(params: dict[str, Any], random_state: int) -> MLPClassifier:
    return MLPClassifier(
        hidden_layer_sizes=tuple(params["hidden_layer_sizes"]),
        activation=params.get("activation", "relu"),
        solver=params.get("solver", "adam"),
        alpha=float(params.get("alpha", 0.0001)),
        learning_rate_init=float(params.get("learning_rate_init", 0.001)),
        batch_size=int(params.get("batch_size", 128)),
        max_iter=int(params.get("max_iter", 45)),
        early_stopping=True,
        validation_fraction=float(params.get("validation_fraction", 0.15)),
        n_iter_no_change=int(params.get("n_iter_no_change", 5)),
        random_state=random_state,
    )


def make_linear_svm(params: dict[str, Any], random_state: int) -> LinearSVC:
    return LinearSVC(
        C=float(params["C"]),
        class_weight=params.get("class_weight", "balanced"),
        random_state=random_state,
    )


def oversample_to_majority(
    X: np.ndarray, y: np.ndarray, random_state: int
) -> tuple[np.ndarray, np.ndarray]:
    """Randomly oversample each class to the majority count."""

    generator = np.random.default_rng(random_state)
    classes, counts = np.unique(y, return_counts=True)
    majority = int(counts.max())
    selected = []
    for class_id in classes:
        indexes = np.flatnonzero(y == class_id)
        selected.append(generator.choice(indexes, size=majority, replace=True))
    combined = np.concatenate(selected)
    generator.shuffle(combined)
    return X[combined], y[combined]
