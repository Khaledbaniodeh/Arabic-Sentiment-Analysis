"""Feature extraction for Arabic sentiment classification."""

from __future__ import annotations

import re
from collections.abc import Iterable

import numpy as np
from scipy import sparse
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion

from .preprocessing import (
    MENTION_RE,
    NEGATIVE_EMOJI_RE,
    NEGATORS,
    POSITIVE_EMOJI_RE,
    URL_RE,
    normalize_arabic_text,
    simple_tokenizer,
)

DIALECT_MARKERS = {
    "انا",
    "انت",
    "انتا",
    "انتي",
    "احنا",
    "مفيش",
    "مش",
    "عايز",
    "عاوزه",
    "ليه",
    "كده",
    "ازاي",
    "ايه",
    "ده",
    "دي",
    "اللي",
    "مو",
    "شو",
    "ليش",
    "كتير",
    "هلق",
    "بدي",
    "شلون",
    "مبسوط",
}

POSITIVE_LEXICON = {
    "ممتاز",
    "جميل",
    "رائع",
    "احب",
    "سعيد",
    "فرح",
    "نجاح",
    "مبروك",
    "شكرا",
    "افضل",
    "حلو",
    "عظيم",
    "احترام",
    "امل",
    "تفاول",
    "فوز",
    "يبارك",
    "الحمدلله",
    "مسرور",
}

NEGATIVE_LEXICON = {
    "سيء",
    "سيئ",
    "قبيح",
    "اكره",
    "حزين",
    "فشل",
    "فاشل",
    "غضب",
    "كارثة",
    "مقرف",
    "لعنة",
    "خائن",
    "فساد",
    "قتل",
    "ظلم",
    "عار",
    "اسوا",
    "كره",
    "ارهاب",
    "ممل",
    "وجع",
}

HANDCRAFTED_FEATURE_NAMES = [
    "normalized_character_count",
    "normalized_token_count",
    "hashtag_count",
    "mention_count",
    "url_count",
    "exclamation_count",
    "question_count",
    "positive_emoji_count",
    "negative_emoji_count",
    "elongation_count",
    "negation_count",
    "dialect_marker_count",
    "arabic_character_ratio",
    "punctuation_ratio",
    "digit_count",
    "positive_lexicon_hits",
    "negative_lexicon_hits",
]


class HandcraftedArabicFeatures(BaseEstimator, TransformerMixin):
    """Extract non-negative linguistic and structural features.

    The features are normalized to comparable ranges and returned as a sparse matrix,
    allowing direct concatenation with TF-IDF representations and compatibility with
    multinomial Naive Bayes.
    """

    def fit(self, X: Iterable[str], y: object = None) -> HandcraftedArabicFeatures:
        return self

    def transform(self, X: Iterable[str]) -> sparse.csr_matrix:
        rows: list[list[float]] = []
        for raw_text in X:
            text = str(raw_text)
            normalized = normalize_arabic_text(text)
            tokens = normalized.split()
            arabic_characters = sum("\u0600" <= char <= "\u06ff" for char in text)
            punctuation = sum(char in "!?؟،.,؛:" for char in text)

            rows.append(
                [
                    min(len(text), 500) / 500.0,
                    min(len(tokens), 100) / 100.0,
                    min(text.count("#"), 20) / 20.0,
                    min(len(MENTION_RE.findall(text)), 10) / 10.0,
                    min(len(URL_RE.findall(text)), 5) / 5.0,
                    min(text.count("!"), 10) / 10.0,
                    min(text.count("?") + text.count("؟"), 10) / 10.0,
                    min(len(POSITIVE_EMOJI_RE.findall(text)), 10) / 10.0,
                    min(len(NEGATIVE_EMOJI_RE.findall(text)), 10) / 10.0,
                    min(len(re.findall(r"(.)\1{2,}", text)), 10) / 10.0,
                    min(sum(token in NEGATORS for token in tokens), 10) / 10.0,
                    min(sum(token in DIALECT_MARKERS for token in tokens), 10) / 10.0,
                    arabic_characters / max(len(text), 1),
                    punctuation / max(len(text), 1),
                    min(sum(char.isdigit() for char in text), 20) / 20.0,
                    min(sum(token in POSITIVE_LEXICON for token in tokens), 10) / 10.0,
                    min(sum(token in NEGATIVE_LEXICON for token in tokens), 10) / 10.0,
                ]
            )
        return sparse.csr_matrix(np.asarray(rows, dtype=np.float32))

    def get_feature_names_out(self, input_features: object = None) -> np.ndarray:
        return np.asarray(HANDCRAFTED_FEATURE_NAMES, dtype=object)


def build_feature_extractor(config: dict) -> FeatureUnion:
    """Build the combined word, character, and handcrafted feature extractor."""

    word = config["word_tfidf"]
    char = config["char_tfidf"]
    return FeatureUnion(
        [
            (
                "word_tfidf",
                TfidfVectorizer(
                    preprocessor=normalize_arabic_text,
                    tokenizer=simple_tokenizer,
                    token_pattern=None,
                    ngram_range=tuple(word["ngram_range"]),
                    min_df=word["min_df"],
                    max_df=word["max_df"],
                    max_features=word["max_features"],
                    sublinear_tf=word.get("sublinear_tf", True),
                    lowercase=False,
                    dtype=np.float32,
                ),
            ),
            (
                "char_tfidf",
                TfidfVectorizer(
                    preprocessor=normalize_arabic_text,
                    analyzer="char_wb",
                    ngram_range=tuple(char["ngram_range"]),
                    min_df=char["min_df"],
                    max_features=char["max_features"],
                    sublinear_tf=char.get("sublinear_tf", True),
                    lowercase=False,
                    dtype=np.float32,
                ),
            ),
            ("handcrafted", HandcraftedArabicFeatures()),
        ]
    )
