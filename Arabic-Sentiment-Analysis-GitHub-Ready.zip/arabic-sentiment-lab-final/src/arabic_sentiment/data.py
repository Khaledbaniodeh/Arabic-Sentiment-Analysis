"""Dataset loading, validation, profiling, and deterministic splitting."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


@dataclass(frozen=True)
class DatasetAudit:
    total_rows: int
    usable_rows: int
    duplicate_rows_removed: int
    empty_text_rows: int
    malformed_rows: int
    conflicting_duplicate_texts: int
    class_counts_raw: dict[str, int]
    class_counts_merged: dict[str, int]

    def as_dict(self) -> dict:
        return {
            "total_rows": self.total_rows,
            "usable_rows": self.usable_rows,
            "duplicate_rows_removed": self.duplicate_rows_removed,
            "empty_text_rows": self.empty_text_rows,
            "malformed_rows": self.malformed_rows,
            "conflicting_duplicate_texts": self.conflicting_duplicate_texts,
            "class_counts_raw": self.class_counts_raw,
            "class_counts_merged": self.class_counts_merged,
        }


def load_dataset(path: str | Path, deduplicate: bool = True) -> tuple[pd.DataFrame, DatasetAudit]:
    """Load a right-tab-delimited text dataset.

    Splitting from the right protects against tab characters occurring inside a post.
    The assignment defines three target classes, so ``OBJ`` and ``NEUTRAL`` are merged
    into the canonical ``NEUTRAL`` class.
    """

    source = Path(path)
    if not source.exists():
        raise FileNotFoundError(f"Dataset not found: {source}")

    rows: list[tuple[str, str]] = []
    malformed = 0
    with source.open("r", encoding="utf-8-sig") as handle:
        for line in handle:
            value = line.rstrip("\r\n")
            if "\t" not in value:
                malformed += 1
                continue
            text, raw_label = value.rsplit("\t", 1)
            label = raw_label.strip().upper()
            if label not in {"POS", "NEG", "OBJ", "NEUTRAL"}:
                malformed += 1
                continue
            rows.append((text.strip(), label))

    frame = pd.DataFrame(rows, columns=["text", "label_raw"])
    empty_rows = int(frame["text"].eq("").sum())
    frame = frame.loc[~frame["text"].eq("")].copy()
    frame["label"] = frame["label_raw"].replace({"OBJ": "NEUTRAL"})

    conflicts = int((frame.groupby("text")["label"].nunique() > 1).sum())
    duplicates = int(frame.duplicated(subset=["text", "label"]).sum())
    if deduplicate:
        frame = frame.drop_duplicates(subset=["text", "label"], keep="first").reset_index(drop=True)

    frame.insert(0, "row_id", np.arange(len(frame), dtype=int))
    audit = DatasetAudit(
        total_rows=len(rows) + malformed,
        usable_rows=len(frame),
        duplicate_rows_removed=duplicates if deduplicate else 0,
        empty_text_rows=empty_rows,
        malformed_rows=malformed,
        conflicting_duplicate_texts=conflicts,
        class_counts_raw={
            str(k): int(v) for k, v in pd.Series([r[1] for r in rows]).value_counts().items()
        },
        class_counts_merged={str(k): int(v) for k, v in frame["label"].value_counts().items()},
    )
    return frame, audit


def stratified_split(
    frame: pd.DataFrame,
    train_size: float,
    validation_size: float,
    test_size: float,
    random_state: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    total = train_size + validation_size + test_size
    if not np.isclose(total, 1.0):
        raise ValueError(f"Split proportions must sum to 1.0, received {total}.")

    train_validation, test = train_test_split(
        frame,
        test_size=test_size,
        random_state=random_state,
        stratify=frame["label"],
    )
    relative_validation = validation_size / (train_size + validation_size)
    train, validation = train_test_split(
        train_validation,
        test_size=relative_validation,
        random_state=random_state,
        stratify=train_validation["label"],
    )
    return (
        train.reset_index(drop=True),
        validation.reset_index(drop=True),
        test.reset_index(drop=True),
    )


def split_manifest(
    train: pd.DataFrame, validation: pd.DataFrame, test: pd.DataFrame
) -> pd.DataFrame:
    parts = []
    for name, split in (("train", train), ("validation", validation), ("test", test)):
        current = split.copy()
        current["split"] = name
        parts.append(current)
    return pd.concat(parts, ignore_index=True).sort_values("row_id").reset_index(drop=True)
