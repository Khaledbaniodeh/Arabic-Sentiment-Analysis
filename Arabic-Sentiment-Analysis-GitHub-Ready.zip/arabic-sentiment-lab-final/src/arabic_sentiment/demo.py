"""Interactive Gradio demonstration."""

from __future__ import annotations

import os
from pathlib import Path

import gradio as gr
import joblib

from .modeling import ModelBundle


def _load_bundle() -> ModelBundle:
    model_path = Path(os.getenv("MODEL_PATH", "artifacts/models/best_model.joblib"))
    if not model_path.exists():
        raise FileNotFoundError(f"Run training first. Missing model: {model_path}")
    return joblib.load(model_path)


def build_demo() -> gr.Interface:
    bundle = _load_bundle()

    def classify(text: str) -> dict[str, float]:
        if not text or not text.strip():
            return {label: 0.0 for label in bundle.label_encoder.classes_}
        return bundle.predict_with_scores([text])[0]["scores"]

    return gr.Interface(
        fn=classify,
        inputs=gr.Textbox(
            lines=5,
            label="Arabic text",
            placeholder="اكتب منشوراً عربياً هنا...",
            rtl=True,
        ),
        outputs=gr.Label(num_top_classes=3, label="Sentiment scores"),
        title="Arabic Sentiment Analysis",
        description=(
            "A reproducible word + character TF-IDF system with Arabic-specific preprocessing "
            "and hand-engineered social-media features."
        ),
        examples=[
            ["شكرا كلامك كان رائعا"],
            ["كذب وفساد وفضائح شيء مقرف"],
            ["سيعقد المؤتمر غدا في الساعة العاشرة"],
        ],
        flagging_mode="never",
    )


def main() -> None:
    build_demo().launch()


if __name__ == "__main__":
    main()
