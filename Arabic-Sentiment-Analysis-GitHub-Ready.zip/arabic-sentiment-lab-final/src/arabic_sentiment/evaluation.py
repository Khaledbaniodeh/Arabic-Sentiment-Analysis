"""Evaluation utilities and publication-ready plots."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
)

LABEL_ORDER = ["NEG", "NEUTRAL", "POS"]


def compute_metrics(
    y_true: np.ndarray, y_pred: np.ndarray, labels: list[str] = LABEL_ORDER
) -> dict[str, Any]:
    macro = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="macro", zero_division=0
    )
    weighted = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, average="weighted", zero_division=0
    )
    report = classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0)
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_precision": float(macro[0]),
        "macro_recall": float(macro[1]),
        "macro_f1": float(macro[2]),
        "weighted_precision": float(weighted[0]),
        "weighted_recall": float(weighted[1]),
        "weighted_f1": float(weighted[2]),
        "classification_report": report,
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
    }


def save_json(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def plot_class_distribution(counts: dict[str, int], output: Path) -> None:
    labels = [label for label in LABEL_ORDER if label in counts]
    values = [counts[label] for label in labels]
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    bars = ax.bar(labels, values)
    ax.set_title("Merged Sentiment Class Distribution")
    ax.set_xlabel("Sentiment class")
    ax.set_ylabel("Number of posts")
    ax.bar_label(bars, padding=3)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_text_length_distribution(frame: pd.DataFrame, output: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.0, 4.8))
    for label in LABEL_ORDER:
        lengths = frame.loc[frame["label"] == label, "text"].str.len().clip(upper=350)
        ax.hist(lengths, bins=35, alpha=0.5, label=label)
    ax.set_title("Post Length Distribution by Sentiment")
    ax.set_xlabel("Characters per post (clipped at 350)")
    ax.set_ylabel("Frequency")
    ax.legend()
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_confusion_matrix(matrix: list[list[int]], model_name: str, output: Path) -> None:
    values = np.asarray(matrix)
    fig, ax = plt.subplots(figsize=(5.7, 5.0))
    image = ax.imshow(values, cmap="Blues")
    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    ax.set(
        xticks=np.arange(len(LABEL_ORDER)),
        yticks=np.arange(len(LABEL_ORDER)),
        xticklabels=LABEL_ORDER,
        yticklabels=LABEL_ORDER,
        xlabel="Predicted label",
        ylabel="True label",
        title=f"Confusion Matrix - {model_name}",
    )
    threshold = values.max() / 2.0 if values.size else 0
    for row in range(values.shape[0]):
        for column in range(values.shape[1]):
            ax.text(
                column,
                row,
                int(values[row, column]),
                ha="center",
                va="center",
                color="white" if values[row, column] > threshold else "black",
            )
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_model_comparison(results: list[dict[str, Any]], output: Path) -> None:
    frame = pd.DataFrame(
        [
            {
                "model": row["display_name"],
                "Accuracy": row["test_metrics"]["accuracy"],
                "Macro F1": row["test_metrics"]["macro_f1"],
                "Weighted F1": row["test_metrics"]["weighted_f1"],
            }
            for row in results
        ]
    ).set_index("model")
    ax = frame.plot(kind="bar", figsize=(9.2, 5.2), ylim=(0, 1.0), rot=12)
    ax.set_title("Held-out Test Performance")
    ax.set_xlabel("")
    ax.set_ylabel("Score")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(loc="lower right")
    for container in ax.containers:
        ax.bar_label(container, fmt="%.3f", fontsize=8, padding=2)
    fig = ax.get_figure()
    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)
