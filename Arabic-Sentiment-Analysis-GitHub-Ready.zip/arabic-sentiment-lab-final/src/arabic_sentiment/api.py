"""FastAPI inference service."""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .modeling import ModelBundle


class PredictionRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000, description="Arabic social-media text")


class BatchPredictionRequest(BaseModel):
    texts: list[str] = Field(min_length=1, max_length=128)


class PredictionResponse(BaseModel):
    label: str
    confidence: float
    scores: dict[str, float]


@lru_cache(maxsize=1)
def load_model() -> ModelBundle:
    model_path = Path(os.getenv("MODEL_PATH", "artifacts/models/best_model.joblib"))
    if not model_path.exists():
        raise FileNotFoundError(
            f"Model not found at {model_path}. Run training first or set MODEL_PATH."
        )
    bundle = joblib.load(model_path)
    if not isinstance(bundle, ModelBundle):
        raise TypeError("The model artifact is not a valid ModelBundle.")
    return bundle


app = FastAPI(
    title="Arabic Sentiment Analysis API",
    description="Predict Positive, Negative, or Objective/Neutral sentiment for Arabic text.",
    version="1.0.0",
)


@app.get("/health")
def health() -> dict[str, str]:
    try:
        bundle = load_model()
        return {"status": "ok", "model": bundle.metadata.get("display_name", "unknown")}
    except Exception as error:  # health endpoint should expose startup issues clearly
        raise HTTPException(status_code=503, detail=str(error)) from error


@app.get("/model")
def model_metadata() -> dict:
    try:
        return load_model().metadata
    except Exception as error:
        raise HTTPException(status_code=503, detail=str(error)) from error


@app.post("/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest) -> dict:
    try:
        return load_model().predict_with_scores([request.text])[0]
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error)) from error


@app.post("/predict/batch", response_model=list[PredictionResponse])
def predict_batch(request: BatchPredictionRequest) -> list[dict]:
    if any(not text.strip() for text in request.texts):
        raise HTTPException(status_code=422, detail="Batch texts must be non-empty.")
    try:
        return load_model().predict_with_scores(request.texts)
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error)) from error
