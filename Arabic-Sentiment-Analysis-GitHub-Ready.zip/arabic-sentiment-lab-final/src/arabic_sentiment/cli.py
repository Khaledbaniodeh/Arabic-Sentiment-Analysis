"""Command-line interface for training, reporting, prediction, API, and demo."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib

from .modeling import ModelBundle


def _load_bundle(path: str) -> ModelBundle:
    model_path = Path(path)
    if not model_path.exists():
        raise FileNotFoundError(f"Model not found: {model_path}")
    bundle = joblib.load(model_path)
    if not isinstance(bundle, ModelBundle):
        raise TypeError("Artifact is not a ModelBundle.")
    return bundle


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="arabic-sentiment")
    subparsers = parser.add_subparsers(dest="command", required=True)

    train_parser = subparsers.add_parser("train", help="Run the complete experiment")
    train_parser.add_argument("--config", default="configs/default.yaml")

    report_parser = subparsers.add_parser("report", help="Generate the PDF report")
    report_parser.add_argument("--summary", default="artifacts/metrics/training_summary.json")
    report_parser.add_argument("--plots", default="artifacts/plots")
    report_parser.add_argument("--output", default="docs/Arabic_Sentiment_Analysis_Report.pdf")

    predict_parser = subparsers.add_parser("predict", help="Predict sentiment for one text")
    predict_parser.add_argument("--model", default="artifacts/models/best_model.joblib")
    predict_parser.add_argument("--text", required=True)

    api_parser = subparsers.add_parser("api", help="Run the FastAPI service")
    api_parser.add_argument("--host", default="0.0.0.0")
    api_parser.add_argument("--port", type=int, default=8000)
    api_parser.add_argument("--model", default="artifacts/models/best_model.joblib")

    demo_parser = subparsers.add_parser("demo", help="Run the Gradio demo")
    demo_parser.add_argument("--model", default="artifacts/models/best_model.joblib")

    return parser


def main() -> None:
    import os

    arguments = build_parser().parse_args()
    if arguments.command == "train":
        from .train import train_project

        summary = train_project(arguments.config)
        print(json.dumps(summary["deployment"], ensure_ascii=False, indent=2))
    elif arguments.command == "report":
        from .report import generate_report

        print(generate_report(arguments.summary, arguments.output, arguments.plots))
    elif arguments.command == "predict":
        bundle = _load_bundle(arguments.model)
        print(
            json.dumps(
                bundle.predict_with_scores([arguments.text])[0], ensure_ascii=False, indent=2
            )
        )
    elif arguments.command == "api":
        os.environ["MODEL_PATH"] = arguments.model
        import uvicorn

        uvicorn.run("arabic_sentiment.api:app", host=arguments.host, port=arguments.port)
    elif arguments.command == "demo":
        os.environ["MODEL_PATH"] = arguments.model
        from .demo import main as run_demo

        run_demo()


if __name__ == "__main__":
    main()
