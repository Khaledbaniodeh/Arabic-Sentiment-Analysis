"""Configuration loading and validation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


@dataclass(frozen=True)
class ProjectConfig:
    """Thin typed wrapper around the YAML configuration."""

    raw: dict[str, Any]
    config_path: Path

    @property
    def root(self) -> Path:
        configured = self.raw.get("project_root")
        if configured:
            return Path(configured).expanduser().resolve()
        # configs/default.yaml -> repository root
        return self.config_path.resolve().parent.parent

    def path(self, dotted_key: str) -> Path:
        value = self.get(dotted_key)
        if value is None:
            raise KeyError(f"Missing path configuration: {dotted_key}")
        candidate = Path(str(value)).expanduser()
        return candidate if candidate.is_absolute() else self.root / candidate

    def get(self, dotted_key: str, default: Any = None) -> Any:
        current: Any = self.raw
        for part in dotted_key.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]
        return current


def load_config(path: str | Path) -> ProjectConfig:
    config_path = Path(path).expanduser().resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    with config_path.open("r", encoding="utf-8") as handle:
        payload = yaml.safe_load(handle) or {}
    if not isinstance(payload, dict):
        raise ValueError("The YAML configuration must contain a mapping at the top level.")
    return ProjectConfig(payload, config_path)
