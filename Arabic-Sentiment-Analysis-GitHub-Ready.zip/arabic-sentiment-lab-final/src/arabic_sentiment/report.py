"""Generate a formal PDF report from reproducible training artifacts."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


class NumberedCanvasMixin:
    """Reserved for compatibility; page numbers are added with a callback."""


def _page_number(canvas: Any, document: Any) -> None:
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#5A6472"))
    canvas.drawString(2.0 * cm, 1.2 * cm, "ENCS3340 - Arabic Sentiment Analysis")
    canvas.drawRightString(A4[0] - 2.0 * cm, 1.2 * cm, f"Page {document.page}")
    canvas.restoreState()


def _metric(value: float) -> str:
    return f"{value:.4f}"


def _safe_image(path: Path, width: float) -> Image | Paragraph:
    if path.exists():
        pixel_width, pixel_height = ImageReader(str(path)).getSize()
        height = width * pixel_height / pixel_width
        return Image(str(path), width=width, height=height)
    return Paragraph(f"[Figure unavailable: {path.name}]", getSampleStyleSheet()["BodyText"])


def _table(data: list[list[Any]], widths: list[float] | None = None, font_size: int = 8) -> Table:
    table = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#203864")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), font_size),
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B9C2CF")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F3F6FA")]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    return table


def generate_report(
    summary_path: str | Path, output_path: str | Path, plots_directory: str | Path
) -> Path:
    summary_file = Path(summary_path)
    output_file = Path(output_path)
    plots = Path(plots_directory)
    with summary_file.open("r", encoding="utf-8") as handle:
        summary = json.load(handle)

    output_file.parent.mkdir(parents=True, exist_ok=True)
    document = SimpleDocTemplate(
        str(output_file),
        pagesize=A4,
        rightMargin=1.8 * cm,
        leftMargin=1.8 * cm,
        topMargin=1.7 * cm,
        bottomMargin=1.8 * cm,
        title="Arabic Sentiment Analysis - Machine Learning Project",
        author="Student",
        subject="ENCS3340 Artificial Intelligence",
    )

    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="TitleCenter",
            parent=styles["Title"],
            alignment=TA_CENTER,
            fontSize=24,
            leading=29,
            textColor=colors.HexColor("#203864"),
            spaceAfter=18,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SubtitleCenter",
            parent=styles["Normal"],
            alignment=TA_CENTER,
            fontSize=12,
            leading=17,
            textColor=colors.HexColor("#4D5B70"),
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="BodyJustified",
            parent=styles["BodyText"],
            alignment=TA_JUSTIFY,
            fontSize=10,
            leading=15,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Section",
            parent=styles["Heading1"],
            fontSize=17,
            leading=21,
            textColor=colors.HexColor("#203864"),
            spaceBefore=8,
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Subsection",
            parent=styles["Heading2"],
            fontSize=13,
            leading=17,
            textColor=colors.HexColor("#315B87"),
            spaceBefore=8,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Caption",
            parent=styles["Normal"],
            alignment=TA_CENTER,
            fontSize=8.5,
            leading=11,
            textColor=colors.HexColor("#5A6472"),
            spaceAfter=8,
        )
    )

    story: list[Any] = []
    body = styles["BodyJustified"]

    # Cover page
    story.extend(
        [
            Spacer(1, 1.8 * cm),
            Paragraph("BIRZEIT UNIVERSITY", styles["SubtitleCenter"]),
            Paragraph(
                "Department of Electrical and Computer Engineering", styles["SubtitleCenter"]
            ),
            Spacer(1, 0.5 * cm),
            Paragraph("Arabic Sentiment Analysis", styles["TitleCenter"]),
            Paragraph(
                "Machine Learning Project - ENCS3340 Artificial Intelligence",
                styles["SubtitleCenter"],
            ),
            Spacer(1, 1.2 * cm),
            _table(
                [
                    ["Field", "Value"],
                    ["Student name", "________________________________"],
                    ["Student ID", "________________________________"],
                    ["Instructor", "________________________________"],
                    ["Repository", "Arabic Sentiment Lab"],
                    ["Reproducibility seed", "42"],
                ],
                widths=[4.5 * cm, 10.5 * cm],
                font_size=10,
            ),
            Spacer(1, 1.2 * cm),
            Paragraph(
                "This report is generated directly from the saved experiment artifacts. Every result table and confusion matrix corresponds to a deterministic 60/20/20 split of the supplied dataset.",
                styles["SubtitleCenter"],
            ),
            PageBreak(),
        ]
    )

    story.append(Paragraph("Executive Summary", styles["Section"]))
    deployment = summary["deployment"]
    test_lookup = {row["family"]: row for row in summary["test_results"]}
    deployed_result = test_lookup[deployment["family"]]
    story.append(
        Paragraph(
            "The project implements a complete Arabic social-media sentiment classification lifecycle: dataset auditing, Arabic-aware preprocessing, exploratory analysis, feature engineering, deterministic splitting, validation-based hyperparameter optimization, held-out test evaluation, serialization, command-line prediction, a REST API, and an interactive demo. The required model families - Naive Bayes, Random Forest, and an Artificial Neural Network - are evaluated, with a Linear SVM added as a production-oriented reference model.",
            body,
        )
    )
    story.append(
        Paragraph(
            f"The deployment model is <b>{deployment['display_name']}</b>, selected exclusively by validation macro F1. On the untouched test set it achieved accuracy <b>{_metric(deployed_result['test_metrics']['accuracy'])}</b>, macro F1 <b>{_metric(deployed_result['test_metrics']['macro_f1'])}</b>, and weighted F1 <b>{_metric(deployed_result['test_metrics']['weighted_f1'])}</b>. Macro F1 is emphasized because the data are substantially imbalanced.",
            body,
        )
    )

    story.append(Paragraph("Table of Contents", styles["Section"]))
    toc_rows = [["Section", "Topic"]]
    for number, title in enumerate(
        [
            "Problem Definition",
            "Dataset Analysis",
            "Preprocessing",
            "Feature Engineering",
            "Experimental Methodology",
            "Models and Hyperparameters",
            "Results",
            "Error Analysis and Limitations",
            "Deployment and Reproducibility",
            "Conclusion",
        ],
        start=1,
    ):
        toc_rows.append([str(number), title])
    story.append(_table(toc_rows, widths=[2.0 * cm, 13.0 * cm], font_size=9))
    story.append(PageBreak())

    # Problem
    story.append(Paragraph("1. Problem Definition", styles["Section"]))
    story.append(
        Paragraph(
            "Given an Arabic social-media post, the objective is to predict one of three sentiment categories: Positive, Negative, or Objective/Neutral. The task is a supervised multiclass text-classification problem. The input is a noisy, short, dialect-rich text sequence; the output is a single categorical label.",
            body,
        )
    )
    story.append(
        Paragraph(
            "The main technical challenges are severe class imbalance, spelling and orthographic variation, informal dialect, code mixing, hashtags, emojis, elongation, punctuation-based sentiment, and ambiguous objective posts that may contain emotionally charged words without expressing the author's sentiment.",
            body,
        )
    )

    # Dataset
    story.append(Paragraph("2. Dataset Analysis", styles["Section"]))
    dataset = summary["dataset"]
    story.append(
        _table(
            [
                ["Audit item", "Value"],
                ["Original rows", str(dataset["total_rows"])],
                ["Usable rows after validation", str(dataset["usable_rows"])],
                ["Exact duplicates removed", str(dataset["duplicate_rows_removed"])],
                ["Malformed rows", str(dataset["malformed_rows"])],
                ["Empty texts", str(dataset["empty_text_rows"])],
                ["Conflicting duplicate texts", str(dataset["conflicting_duplicate_texts"])],
            ],
            widths=[8.0 * cm, 7.0 * cm],
        )
    )
    story.append(Spacer(1, 0.25 * cm))
    story.append(
        Paragraph(
            "The original file contains both OBJ and NEUTRAL labels. Because the assignment specifies a single Objective/Neutral target category, these two labels are merged into the canonical NEUTRAL class. This produces a three-class task and prevents an artificial distinction not required by the problem statement.",
            body,
        )
    )
    story.append(_safe_image(plots / "class_distribution.png", 14.8 * cm))
    story.append(
        Paragraph(
            "Figure 1. Class distribution after OBJ/NEUTRAL consolidation.", styles["Caption"]
        )
    )
    story.append(_safe_image(plots / "text_length_distribution.png", 15.0 * cm))
    story.append(Paragraph("Figure 2. Character-length distributions by class.", styles["Caption"]))
    story.append(PageBreak())

    # Preprocessing
    story.append(Paragraph("3. Arabic-aware Preprocessing", styles["Section"]))
    preprocessing_steps = [
        "Unicode NFKC normalization and HTML entity decoding.",
        "HTML-tag removal and standardization of URLs, mentions, and numeric expressions into semantic placeholders.",
        "Standardization of positive and negative emojis before other symbols are removed.",
        "Removal of Arabic diacritics and tatweel.",
        "Unification of common Arabic letter variants, including alef forms, alif maqsura, hamza-on-waw, and hamza-on-ya.",
        "Preservation of hashtag content while separating the marker from the word.",
        "Reduction of exaggerated character repetition to two characters.",
        "Lightweight negation-scope marking for up to three following tokens.",
    ]
    for step in preprocessing_steps:
        story.append(Paragraph(f"- {step}", body))
    story.append(
        Paragraph(
            "Aggressive stemming is intentionally disabled by default. In short dialectal posts, stemming can collapse informative sentiment expressions and produce invalid roots. Instead, character n-grams provide robustness to inflection, spelling differences, and dialectal variation while preserving the original word shape.",
            body,
        )
    )
    story.append(
        Paragraph(
            "Generic stop-word removal is also disabled because Arabic function words and negators can change polarity and are useful inside bigrams. Very frequent terms are controlled by the TF-IDF maximum-document-frequency threshold instead.",
            body,
        )
    )

    # Features
    story.append(Paragraph("4. Feature Engineering", styles["Section"]))
    story.append(Paragraph("4.1 Content-based representations", styles["Subsection"]))
    story.append(
        Paragraph(
            "Word TF-IDF uses unigrams and bigrams to represent lexical sentiment and short compositional phrases. Character TF-IDF uses character n-grams within word boundaries to model Arabic morphology, spelling noise, dialectal variants, and elongated forms. Sublinear term frequency reduces the influence of repeated terms.",
            body,
        )
    )
    story.append(
        Paragraph("4.2 Hand-engineered Arabic and social-media features", styles["Subsection"])
    )
    hand_features = [
        "post and token lengths",
        "hashtags, mentions, URLs, and digits",
        "question and exclamation marks",
        "positive and negative emojis",
        "elongation patterns",
        "negation counts",
        "dialect marker counts",
        "Arabic-character and punctuation ratios",
        "small sentiment lexicon hit counts",
    ]
    story.append(
        Paragraph("The structured feature vector includes " + ", ".join(hand_features) + ".", body)
    )
    feature_info = summary["features"]
    story.append(
        _table(
            [
                ["Feature artifact", "Value"],
                ["Training matrix", str(feature_info["training_matrix_shape"])],
                ["Final train+validation matrix", str(feature_info["final_matrix_shape"])],
                ["SVD components", str(feature_info["svd_components"])],
                ["Final explained variance", _metric(feature_info["final_svd_explained_variance"])],
            ],
            widths=[8.0 * cm, 7.0 * cm],
        )
    )
    story.append(PageBreak())

    # Methodology
    story.append(Paragraph("5. Experimental Methodology", styles["Section"]))
    split = summary["split_sizes"]
    story.append(
        Paragraph(
            f"A stratified, deterministic split is used: {split['train']} posts for training (60%), {split['validation']} for validation (20%), and {split['test']} for final testing (20%). Feature extractors are fitted only on training data during model selection. After hyperparameters are selected, each model is refitted on training plus validation data and evaluated once on the held-out test set.",
            body,
        )
    )
    story.append(
        Paragraph(
            "The primary selection metric is macro F1, which gives equal importance to Positive, Negative, and Neutral performance. Accuracy and weighted F1 are reported as complementary metrics. This prevents the majority Neutral class from dominating model selection.",
            body,
        )
    )
    story.append(
        Paragraph(
            "Class imbalance is handled differently according to model behavior: Random Forest uses random oversampling after SVD; the ANN uses square-root balanced sample weights; Linear SVM uses balanced class weights; Complement Naive Bayes relies on its complement statistics and validation-tuned smoothing.",
            body,
        )
    )

    # Models and hyperparameters
    story.append(Paragraph("6. Models and Selected Hyperparameters", styles["Section"]))
    parameter_rows = [["Model", "Selected parameters", "Validation macro F1"]]
    for family in ["naive_bayes", "random_forest", "neural_network", "linear_svm"]:
        selected = summary["selected_hyperparameters"][family]
        parameter_text = ", ".join(f"{key}={value}" for key, value in selected["params"].items())
        parameter_rows.append(
            [
                Paragraph(DISPLAY_NAME(summary, family), styles["BodyText"]),
                Paragraph(parameter_text, styles["BodyText"]),
                _metric(selected["validation_metrics"]["macro_f1"]),
            ]
        )
    story.append(_table(parameter_rows, widths=[4.2 * cm, 8.8 * cm, 2.4 * cm], font_size=8))
    story.append(
        Paragraph(
            "The ANN is a multilayer perceptron trained with ReLU activations and Adam optimization. Early stopping monitors an internal validation subset, and the reported training iteration count confirms whether convergence occurred before the maximum epoch limit.",
            body,
        )
    )

    # Results
    story.append(Paragraph("7. Results", styles["Section"]))
    result_rows = [
        ["Model", "Accuracy", "Macro Precision", "Macro Recall", "Macro F1", "Weighted F1"]
    ]
    for row in summary["test_results"]:
        metrics = row["test_metrics"]
        result_rows.append(
            [
                Paragraph(row["display_name"], styles["BodyText"]),
                _metric(metrics["accuracy"]),
                _metric(metrics["macro_precision"]),
                _metric(metrics["macro_recall"]),
                _metric(metrics["macro_f1"]),
                _metric(metrics["weighted_f1"]),
            ]
        )
    story.append(
        _table(
            result_rows,
            widths=[4.5 * cm, 2.0 * cm, 2.3 * cm, 2.1 * cm, 2.0 * cm, 2.1 * cm],
            font_size=7.6,
        )
    )
    story.append(Spacer(1, 0.3 * cm))
    story.append(_safe_image(plots / "model_comparison.png", 15.5 * cm))
    story.append(
        Paragraph(
            "Figure 3. Held-out test comparison across all evaluated models.", styles["Caption"]
        )
    )
    story.append(PageBreak())

    figure_number = 4
    for family in ["naive_bayes", "random_forest", "neural_network", "linear_svm"]:
        story.append(_safe_image(plots / f"confusion_matrix_{family}.png", 12.8 * cm))
        story.append(
            Paragraph(
                f"Figure {figure_number}. Test confusion matrix for {DISPLAY_NAME(summary, family)}.",
                styles["Caption"],
            )
        )
        figure_number += 1
        if family in {"random_forest", "linear_svm"}:
            story.append(PageBreak())

    # Discussion
    story.append(Paragraph("8. Error Analysis and Limitations", styles["Section"]))
    discussion = [
        "The Neutral class dominates the corpus, so a model can obtain deceptively high accuracy while failing to recover Positive posts.",
        "Many posts are news headlines or political statements whose lexical content is negative even when the intended annotation is objective.",
        "Sarcasm, irony, and cultural references remain difficult for TF-IDF and shallow neural representations.",
        "The Positive class is small, limiting the diversity of positive dialectal expressions seen during training.",
        "Emoji and hashtag features help, but many posts express sentiment without explicit sentiment words.",
        "The dataset reflects a particular social-media domain and time period; generalization to modern platforms or other Arabic dialects requires re-evaluation.",
    ]
    for item in discussion:
        story.append(Paragraph(f"- {item}", body))
    story.append(
        Paragraph(
            "Future improvements include transformer fine-tuning with MARBERT or AraBERT, dialect-aware augmentation, calibrated probabilities, annotation review for ambiguous examples, and monitoring for temporal drift. These are intentionally separated from the required classical machine-learning comparison so the submitted results remain reproducible on ordinary hardware.",
            body,
        )
    )

    # Deployment
    story.append(Paragraph("9. Deployment and Reproducibility", styles["Section"]))
    story.append(
        Paragraph(
            "The repository contains a serialized end-to-end inference bundle, a command-line interface, a FastAPI service, a Gradio demo, Docker support, unit tests, a model card, and GitHub Actions CI. The bundle contains the exact feature extractor, optional dimensionality reducer, scaler, label encoder, estimator, and model metadata used in the final experiment.",
            body,
        )
    )
    environment = summary["environment"]
    story.append(_safe_image(plots / "cli_prediction_example.png", 15.2 * cm))
    story.append(
        Paragraph(
            "Figure 8. Snapshot of command-line prediction and API startup output.",
            styles["Caption"],
        )
    )
    story.append(
        _table(
            [
                ["Reproducibility item", "Value"],
                ["Python", environment["python"]],
                ["Scikit-learn", environment["scikit_learn"]],
                ["NumPy", environment["numpy"]],
                ["Pandas", environment["pandas"]],
                ["Random seed", "42"],
                ["Deployment artifact", deployment["model_path"]],
                ["Model artifact size", f"{deployment['file_size_bytes'] / (1024 * 1024):.2f} MB"],
            ],
            widths=[7.0 * cm, 8.0 * cm],
        )
    )

    story.append(Paragraph("10. Conclusion", styles["Section"]))
    story.append(
        Paragraph(
            "This project demonstrates that a carefully engineered classical NLP system can provide a transparent and reproducible Arabic sentiment baseline. The combination of Arabic normalization, word and character TF-IDF, negation handling, and social-media features is effective despite severe class imbalance and noisy dialectal text. The comparative design also shows why macro-level metrics and class-specific confusion matrices are essential when selecting a model for real use.",
            body,
        )
    )

    story.append(Paragraph("References", styles["Section"]))
    references = [
        "Breiman, L. (2001). Random Forests. Machine Learning, 45, 5-32.",
        "Rennie, J. D. M., Shih, L., Teevan, J., and Karger, D. R. (2003). Tackling the Poor Assumptions of Naive Bayes Text Classifiers. ICML.",
        "Salton, G., and Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. Information Processing and Management, 24(5), 513-523.",
        "Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. Journal of Machine Learning Research, 12, 2825-2830.",
        "Project source code and experiment artifacts in the accompanying GitHub-ready repository.",
    ]
    for reference in references:
        story.append(Paragraph(reference, body))

    document.build(story, onFirstPage=_page_number, onLaterPages=_page_number)
    return output_file


def DISPLAY_NAME(summary: dict[str, Any], family: str) -> str:
    for row in summary.get("test_results", []):
        if row.get("family") == family:
            return str(row.get("display_name", family))
    selected = summary.get("selected_hyperparameters", {}).get(family, {})
    return str(selected.get("display_name", family))


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Generate the project PDF report.")
    parser.add_argument("--summary", default="artifacts/metrics/training_summary.json")
    parser.add_argument("--plots", default="artifacts/plots")
    parser.add_argument("--output", default="docs/Arabic_Sentiment_Analysis_Report.pdf")
    arguments = parser.parse_args()
    generated = generate_report(arguments.summary, arguments.output, arguments.plots)
    print(generated)


if __name__ == "__main__":
    main()
