#!/usr/bin/env bash
set -euo pipefail

python -m pip install -e .
python -m arabic_sentiment.cli train --config configs/default.yaml
python -m arabic_sentiment.cli report
pytest
