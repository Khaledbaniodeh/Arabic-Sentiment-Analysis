# Model Card

## Intended use

Classify short Arabic social-media text into `POS`, `NEG`, or `NEUTRAL`. Suitable for educational analysis, dashboard triage, and offline research baselines.

## Out-of-scope use

Do not use the model as the sole basis for moderation, disciplinary action, mental-health inference, political profiling, or decisions affecting a person's rights. The model is not a factuality, toxicity, or intent detector.

## Training data

The supplied dataset contains approximately ten thousand posts and is strongly imbalanced toward Objective/Neutral. Raw `OBJ` and `NEUTRAL` annotations are consolidated into one target.

## Metrics

See `artifacts/metrics/test_model_comparison.csv` and the generated PDF report. Macro F1 is the main metric because it weights all classes equally.

## Limitations

- Domain and time-period shift.
- Limited Positive examples.
- Sarcasm and irony.
- Ambiguous political/news language.
- Dialect coverage is incomplete.
- Confidence values are model scores and are not guaranteed to be calibrated probabilities.

## Reproducibility

The random seed, split manifest, selected hyperparameters, package versions, feature dimensions, and full test results are stored in `artifacts/metrics/training_summary.json`.
