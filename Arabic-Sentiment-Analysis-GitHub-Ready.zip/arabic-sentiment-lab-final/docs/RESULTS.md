# Experiment Results

The experiment was executed on the supplied dataset after removing 5 exact duplicates, leaving 10,001 posts. The merged class distribution is 7,518 Neutral, 1,684 Negative, and 799 Positive.

| Model | Accuracy | Macro Precision | Macro Recall | Macro F1 | Weighted F1 |
|---|---:|---:|---:|---:|---:|
| Complement Naive Bayes | 0.6952 | 0.5172 | 0.5451 | 0.5280 | 0.7049 |
| Linear SVM (production baseline) | 0.7446 | 0.5639 | 0.5004 | 0.5234 | 0.7272 |
| Random Forest | 0.7486 | 0.5877 | 0.4301 | 0.4510 | 0.7081 |
| Artificial Neural Network | 0.7346 | 0.5294 | 0.4646 | 0.4854 | 0.7116 |

The deployment artifact is **Linear SVM (production baseline)**, selected by validation macro F1 without consulting the test set. The model file is approximately 1.52 MB.

Detailed class-level reports and confusion matrices are available under `artifacts/metrics/` and `artifacts/plots/`.
