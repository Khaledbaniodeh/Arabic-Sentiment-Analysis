# Demo and Defense Guide

## Five-minute live demonstration

1. Run `python -m arabic_sentiment.cli predict --text "شكرا كلامك كان رائعا"`.
2. Run `python -m arabic_sentiment.cli demo` and test one positive, one negative, and one neutral post.
3. Open `artifacts/metrics/test_model_comparison.csv` and explain why macro F1 is the main selection metric.
4. Open the confusion matrices under `artifacts/plots/`.
5. Start the API with `python -m arabic_sentiment.cli api` and open `/docs` in the browser.

## Design questions to be ready for

### Why merge OBJ and NEUTRAL?
The assignment specifies three target categories and describes Objective/Neutral as one class. Keeping both raw labels would create a fourth target that the project did not request.

### Why use both word and character TF-IDF?
Word n-grams capture phrases and lexical polarity. Character n-grams handle Arabic morphology, dialect, spelling variation, elongation, and noisy social-media writing.

### Why not stem every word?
Aggressive stemming can destroy short dialectal sentiment expressions. Character n-grams provide robustness without discarding the surface form. The choice is deliberate and documented.

### Why macro F1 rather than accuracy?
Neutral posts dominate the data. Accuracy can be high even when Positive examples are ignored. Macro F1 gives equal weight to every class.

### How was the test set protected?
Hyperparameters are selected on the validation split only. The test split is transformed and scored after selection and final refitting.

### How is imbalance handled?
Random Forest uses oversampling, the ANN uses square-root balanced sample weights, the SVM uses balanced class weights, and Complement Naive Bayes is tuned with macro F1.

### What makes the project production-ready?
It includes input validation, deterministic experiments, saved metadata, a serializable inference bundle, batch prediction, FastAPI, Gradio, Docker, tests, CI, a model card, and a reproducible PDF report.

## Safe minor modifications during the demo

- Change `C` values for the SVM in `configs/default.yaml`.
- Add another hidden-layer candidate to the ANN.
- Change the negation scope in `normalize_arabic_text`.
- Add a new dialect marker or emoji to the handcrafted features.
- Change the random seed and explain why metrics may shift slightly.
