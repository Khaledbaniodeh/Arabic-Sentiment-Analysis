# رفع المشروع على GitHub

من داخل مجلد المشروع:

```bash
git init
git branch -M main
git add .
git commit -m "Complete Arabic sentiment analysis project"
```

أنشئ repository جديداً وفارغاً على GitHub، ثم نفذ:

```bash
git remote add origin https://github.com/YOUR_USERNAME/arabic-sentiment-lab.git
git push -u origin main
```

قبل التسليم غيّر حقول الاسم والرقم الجامعي في الصفحة الأولى من التقرير. التقرير الحالي يحتوي خطوطاً فارغة لهذه البيانات.

## اقتراح وصف للـ repository

> Reproducible Arabic sentiment analysis using Arabic-aware preprocessing, TF-IDF, handcrafted features, Naive Bayes, Random Forest, MLP, Linear SVM, FastAPI, Gradio, Docker, and automated evaluation.

## Topics مقترحة

`arabic-nlp`, `sentiment-analysis`, `machine-learning`, `scikit-learn`, `fastapi`, `gradio`, `tfidf`
