# Architecture

```text
TSV dataset
   |
   v
validation + label consolidation + deduplication
   |
   v
stratified 60/20/20 split
   |
   +--> EDA plots and audit metadata
   |
   v
Arabic normalization
   |
   +--> word TF-IDF (1-2 grams)
   +--> character TF-IDF (3-5 grams)
   +--> handcrafted linguistic/social features
   |
   v
sparse feature union
   |
   +--> Complement Naive Bayes
   +--> Linear SVM
   |
   +--> TruncatedSVD --> Random Forest
   |
   +--> TruncatedSVD --> StandardScaler --> MLP neural network
   |
   v
validation macro-F1 selection
   |
   v
refit on train + validation
   |
   v
held-out test evaluation + model bundle + API/demo/report
```

The inference bundle is intentionally explicit rather than a single opaque pipeline. It stores the feature extractor, optional reducer, optional scaler, label encoder, estimator, and metadata. This makes model inspection and debugging straightforward.
