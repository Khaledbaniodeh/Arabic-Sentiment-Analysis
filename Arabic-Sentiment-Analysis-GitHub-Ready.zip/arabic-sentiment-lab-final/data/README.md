# Data setup

The original dataset is intentionally not included in the public GitHub package because its redistribution terms were not provided.

Place the supplied UTF-8 dataset at:

```text
data/raw/arabic_sentiment.tsv
```

Expected format:

```text
Arabic text<TAB>LABEL
```

Supported original labels are `POS`, `NEG`, `OBJ`, and `NEUTRAL`. The loader preserves the original label and maps both `OBJ` and `NEUTRAL` to the final `NEUTRAL` target class.

A tiny synthetic example is available at `data/samples/sample_dataset.tsv`; it is only for format inspection and must not be used to reproduce the reported metrics.
