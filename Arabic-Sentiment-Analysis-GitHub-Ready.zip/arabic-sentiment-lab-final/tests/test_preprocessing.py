from arabic_sentiment.preprocessing import normalize_arabic_text


def test_normalization_standardizes_noise() -> None:
    normalized = normalize_arabic_text("أحبببب هذا! https://example.com @user 123 😊")
    assert "احبب" in normalized
    assert "رابط" in normalized
    assert "مستخدم" in normalized
    assert "رقم" in normalized
    assert "ايموجي" in normalized
    assert "http" not in normalized


def test_negation_scope_is_marked() -> None:
    normalized = normalize_arabic_text("مش حلو ابدا اليوم")
    assert "مش" in normalized
    assert "نفي_حلو" in normalized
