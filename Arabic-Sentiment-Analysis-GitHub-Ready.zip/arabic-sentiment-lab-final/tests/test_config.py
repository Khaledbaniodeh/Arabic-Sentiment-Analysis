from pathlib import Path

from arabic_sentiment.config import load_config


def test_config_resolves_repo_relative_paths() -> None:
    config = load_config(Path("configs/default.yaml"))
    assert config.path("data.path").name == "arabic_sentiment.tsv"
    assert config.get("data.split.train") == 0.6
