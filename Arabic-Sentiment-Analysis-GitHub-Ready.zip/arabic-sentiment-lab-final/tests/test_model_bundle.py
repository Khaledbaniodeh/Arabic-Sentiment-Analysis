import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import ComplementNB
from sklearn.preprocessing import LabelEncoder

from arabic_sentiment.modeling import ModelBundle


def test_model_bundle_predicts_and_scores() -> None:
    texts = ["رائع جميل", "سيء جدا", "خبر اليوم"]
    labels = np.array(["POS", "NEG", "NEUTRAL"])
    encoder = LabelEncoder().fit(labels)
    vectorizer = TfidfVectorizer().fit(texts)
    model = ComplementNB().fit(vectorizer.transform(texts), encoder.transform(labels))
    bundle = ModelBundle(vectorizer, model, encoder)

    result = bundle.predict_with_scores(["رائع"])[0]
    assert result["label"] in set(labels)
    assert set(result["scores"]) == set(labels)
    assert 0.0 <= result["confidence"] <= 1.0
