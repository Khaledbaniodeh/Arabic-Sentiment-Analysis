from pathlib import Path

from arabic_sentiment.data import load_dataset, stratified_split


def test_loader_right_splits_and_merges_labels(tmp_path: Path) -> None:
    dataset = tmp_path / "sample.tsv"
    dataset.write_text(
        "نص فيه\tعلامة داخلية\tOBJ\nممتاز جدا\tPOS\nسيء جدا\tNEG\nخبر عادي\tNEUTRAL\n",
        encoding="utf-8",
    )
    frame, audit = load_dataset(dataset)
    assert len(frame) == 4
    assert frame.loc[0, "text"].endswith("علامة داخلية")
    assert set(frame["label"]) == {"POS", "NEG", "NEUTRAL"}
    assert audit.malformed_rows == 0


def test_stratified_split_sizes() -> None:
    rows = []
    for label in ["POS", "NEG", "NEUTRAL"]:
        for index in range(20):
            rows.append(
                {
                    "row_id": len(rows),
                    "text": f"{label}-{index}",
                    "label_raw": label,
                    "label": label,
                }
            )
    import pandas as pd

    frame = pd.DataFrame(rows)
    train, validation, test = stratified_split(frame, 0.6, 0.2, 0.2, 42)
    assert (len(train), len(validation), len(test)) == (36, 12, 12)
    assert set(train["label"]) == {"POS", "NEG", "NEUTRAL"}
