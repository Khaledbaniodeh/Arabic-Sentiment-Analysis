import numpy as np

from arabic_sentiment.features import HandcraftedArabicFeatures


def test_handcrafted_features_are_non_negative() -> None:
    transformer = HandcraftedArabicFeatures()
    matrix = transformer.fit_transform(["خبر عادي", "سيء!!! 😢 #غضب", "ممتاز 😊"])
    assert matrix.shape == (3, 17)
    assert np.all(matrix.toarray() >= 0)
    assert len(transformer.get_feature_names_out()) == 17
