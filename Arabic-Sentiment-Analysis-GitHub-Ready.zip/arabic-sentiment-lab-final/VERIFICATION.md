# Verification record

The packaged project was checked in the provided execution environment.

## Automated checks

```text
pytest -q
.......                                                                  [100%]
```

```text
ruff check src tests
All checks passed!
```

```text
ruff format --check src tests
All files formatted
```

## Saved-model smoke test

The serialized `ModelBundle` was loaded from `artifacts/models/best_model.joblib` and successfully produced a prediction for a new Arabic input.

## Reproducibility boundary

The committed metrics and model were generated from the supplied 10,006-line dataset after removing 5 exact duplicates. Re-running training requires placing the original dataset at `data/raw/arabic_sentiment.tsv`.
